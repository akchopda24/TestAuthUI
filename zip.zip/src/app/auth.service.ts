// src/app/auth.service.ts

import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:44314/api/test'; // Change this URL to your API endpoint

  async authenticate(username: string, password: string): Promise<boolean> {
    try {
      const response = await axios.get(this.apiUrl, {
        headers: {
          'Authorization': 'Basic ' + btoa(username + ':' + password)
        }
      });
      return response.status === 200;
    } catch (error) {
      return false;
    }
  }
}
